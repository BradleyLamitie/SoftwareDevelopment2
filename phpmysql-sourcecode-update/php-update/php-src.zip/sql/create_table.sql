CREATE TABLE IF NOT EXISTS fruit 
(
  id	INT ,
  name	TEXT ,
  color	TEXT
) ;