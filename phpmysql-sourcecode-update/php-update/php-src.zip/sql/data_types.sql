CREATE TABLE IF NOT EXISTS user_log
(
  id	INT ,
  date	TIMESTAMP ,
  first_name	VARCHAR(20),
  last_name	VARCHAR(20)
) ;