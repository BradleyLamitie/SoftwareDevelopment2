<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Getting Started With PHP</title>
</head>
<body>
<?php
# Write the traditional greeting.
echo '<h1>Hello World!</h1>' ;
?>
</body>
</html>