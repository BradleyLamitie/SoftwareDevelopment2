<?php
function qlConfirm(){
 echo '<link rel="stylesheet" href="Limbo.css">';
 
  
 echo('<div id="leftrectangle"></div>');
echo('<div id = "rightrectangle"><img src = "includes/logo.png" id="logo">');
echo('</div>');

	echo('<form action="landing.php"> 	<input type="submit" value="Limbo Home" class="sideButton" id="button1" /></form>');
   echo(' <form action="contactSuperAdmin.php"><input class="sideButton" id="button2" type="submit" value="Contact Super Admin" style="font-size:13px;"/></form>');

	echo('<div id = "centerContent"> ');
echo("<h1> You have updated the items info successfully!</h1>");
echo('<h3>Please press the back button below to return to the admin home page.</h3>');
echo('	<form action="login.php"><input type="submit" value="Logout"  class="centerButton" /></form>');


//echo($_SESSION['count']);

unset($_SESSION['count']);
if(isset($_POST['logout'])){
	session_destroy();
}

echo('</div>');

}
?>
